LV Boost v0.6.1 — fpSup-Merge compatibility candidate
SIGMA fp, firmware 5.02 only. Experimental; not camera-validated.

MERGE (recommended)
1. Upload this fpSup.BIN to https://ijigen.github.io/fpSup/tools/card-composer/
2. Choose other Sups. Add Shell there for USB diagnostics; enable Fast Start 2
   there if wanted. Use at most one gyro edition and one OpenGate version.
3. Download Merge's ZIP. Install its AutoRun.txt, fpSup.BIN and FPSUPUI folder
   together in the SD card root, after backing up existing files.

Do NOT combine with RAW View (including an uploaded RAW View BIN). It shares
LV Boost's COLOR and preview hooks; static merge checks can miss this conflict.
Do NOT upload the old LV Boost v0.6.0 FS2/Shell card to Merge.

STANDALONE
This ZIP's AutoRun.txt + fpSup.BIN are an ordinary card without Shell or Fast
Start 2. It uses the shared loader's text screen, so no FPSUPUI folder is needed.
Replace BOTH files when changing from an older FS2 card. This is not a BIN-only
migration. Boot with USB unplugged. Existing stored Fast bootstrap bytes and
saved LV Boost preferences are not erased by changing card files.

BEHAVIOR
Choose LV BOOST in COLOR, then +1/+2/+3. Normal shutdown saves the selection;
startup restores it after stable STILL live view. First use defaults to +2.
OFF or another color preset saves LV Boost as disabled. The saved word remains
experimental. No changes to the v0.6.0 LV Boost code, tables or preference format.

OFFLINE EVIDENCE
Source/guidance: ijigen/fpSup ba5f607f87baa741ea05007c7be0b6882d217b84,
tools/card-composer and SUP_BUILD_RULES.en.md (2026-09-26).
16 behavior tests pass. All 54 legal combinations in that Merge snapshot pass
its own parser/composer checks: Shell 3.3.0 (EP83 off/on), Gyro or Gyro Base
1.14.0, OG3K 0.2.6a or OG2K 0.1.3a; ordinary and Fast.
Maximum used BIN: 57,252 / 61,440 bytes.
135 combined-card simulated boots pass: ordinary/reload or ordinary/stored-
bootstrap/warm-hook. All payload entries execute and return; LV Boost's
preview hook runs after freed staging is poisoned; shutdown restores the
combined card's declared firmware patches outside the cave.
Native allocation, I/O, settings APIs and task scheduling are mocked. Peer
recording/USB/OpenGate behavior and real flash persistence are not proved.
A deliberately broken launcher is rejected by exact-card verification.
Ordinary AutoRun stays identical when the fallback level changes; the old
v0.6.0 debug BIN is reproduced with explicit --shell --fs2.

STILL UNVERIFIED
No v0.6.1 camera tests, repeated physical power cycles, capture/JPEG/embedded-
preview isolation, AE, magnification or HDMI/EVF validation. No claim of
compatibility with future Sup releases. Maintainer review/listing is pending.

SOURCE / REPRODUCTION
Local source changes: raw/lv-boost in the existing PR checkout.
Original source/review context: https://github.com/ijigen/fpSup/pull/3
From that checkout, with Python dependencies and extracted 5.02 segments:
  python3 raw/lv-boost/build/build_lv_boost.py --out /tmp/lv-boost-ordinary
  python3 raw/lv-boost/test_lv_boost.py -v
  node raw/lv-boost/test_merge.js /tmp/lv-boost-ordinary/fpSup.BIN /tmp/lv-boost-matrix
  python3 raw/lv-boost/verify_card.py /tmp/lv-boost-ordinary /tmp/lv-boost-matrix/lv-*
Use fresh output directories. No camera/card operation is performed by these.
These local changes and artifacts have not been committed, pushed or published.
