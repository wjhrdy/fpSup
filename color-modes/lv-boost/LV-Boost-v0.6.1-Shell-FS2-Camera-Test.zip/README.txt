LV-Boost-v0.6.1-Shell-FS2 -- a SIGMA fp boot card from fpSup-Merge
Firmware Ver.5.02 on the original fp only.

Contains: fpSup-Shell-v3.3.0, LV Boost v0.6.1 (uploaded)
Fast Start 2: on -- the first boot stores the loader in the camera's settings block,
            which survives a battery pull. After that a power-switch
            restart loads in about 1.4 s without the AutoRun and shows the
            four-box screen; a cold start runs a short AutoRun instead.
            Power off with the USB cable unplugged: with it attached the
            next start is always a cold one.

Install
  1. Copy AutoRun.txt, fpSup.BIN and the FPSUPUI folder to the ROOT of the
     SD card the camera boots from.
  2. Boot with the USB cable unplugged. The fpSup logo appears top left and
     four boxes fill one by one; all four white means loaded, and the
     camera's own UI comes back two seconds later. Boxes that stop filling
     are a load that stopped there.

Remove
  Delete the files or take the card out, then switch the camera off: the
  card writes back every firmware word it changed as the camera powers off.
  If the camera froze instead, take the battery out (USB cable unplugged).

SHA-256
  AutoRun.txt  35a3141f4163c8c1790f38b7a5ba4ec92e99eb2396d2565712641f053bd4f775
  fpSup.BIN    4a6d6c47e374715665f509e464ef78c1166e5a95941b360d9c9da53b3e506561

https://github.com/ijigen/fpSup
