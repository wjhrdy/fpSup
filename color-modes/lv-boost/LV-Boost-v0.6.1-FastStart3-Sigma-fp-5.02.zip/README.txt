LV Boost v0.6.1 + Fast Start 3 — SIGMA fp firmware 5.02

Standalone development/test card. LV Boost alone, without USB Shell,
Indoor mode, Focus Inset or other Sups. First use defaults to +2; the
existing saved level/enabled preference takes precedence. LV Boost
payload bytes are identical to the v0.6.1 ordinary Merge input.

Install
Back up the existing card files. Extract this ZIP and replace AutoRun.txt,
fpSup.BIN and the complete FPSUPUI folder at the card root together.
An older ordinary/FS2 AutoRun must not be reused with this package.
Select LV BOOST in COLOR and choose +1, +2 or +3. OFF or a native color
preset disables its automatic startup restore.
This complete Fast package is not an fpSup-Merge input. Use the separate
v0.6.1 ordinary Merge ZIP when combining Sups. Do not combine with RAW View.

Startup and persistent settings
Fast Start 3 uses the shared stored-loader bootstrap and warm-restart hook,
plus accelerated AutoRun processing. The script temporarily removes the
per-character sleep and restores its stock instruction three times before
handing control to the bootstrap/loader. The BIN is reread on each load.
Fast Start writes loader bytes to the camera's persistent common settings
area, and LV Boost retains its experimental saved preference word.
Deleting the card files or removing the battery does not clear those values.
Do not change unrelated experimental camera settings. This package has not
been installed or physically validated in this session; emulator checks
mock native saving, I/O, allocation and task scheduling. Persistent save/boot
behavior and a restoration procedure for this exact package remain unverified.
No live camera settings experiment or card deployment was performed.

Build
Source: wjhrdy/fpSup commit 3a5aec4711d474ca267f2303c6c9064f1dab0dd9.
With the firmware segments/dependencies described in the module README,
run from the repository root into a fresh directory:
  python3 color-modes/lv-boost/build/build_lv_boost.py --fs2 --out /tmp/lv-boost-fs3
The existing product flag is named --fs2. With the shared builder in this
commit it enables Fast Start 3, including --fast-echo enabled by default.
No loader, bootstrap, BIN or generated AutoRun was hand-edited.

Offline verification, 2026-10-08
- 16 LV Boost behavior/startup tests passed.
- 29 shared boot-chain, loader-hook and splash tests passed.
- Exact included card passed ordinary loader, stored-bootstrap and warm-hook
  emulation: entry returned, resident task survived staging release, declared
  firmware hooks restored at shutdown, saved preference retained.
- Ordinary, Shell diagnostic and Shell+Fast diagnostic variants also passed
  their applicable entry/shutdown paths (10 total paths across four variants).
- LV Boost payload equals the existing v0.6.1 Merge ZIP byte for byte.
- Changing only the default boost level leaves AutoRun byte-identical.
- Fast AutoRun is identical with and without the diagnostic Shell payload.
- Accelerated script and pre-handoff sleep restoration checked offline.
- ZIP contents and all SHA-256 checksums verified.
Physical cold/warm boots, ten shutdown cycles, loading over older cards,
capture/AE isolation, magnification and HDMI/EVF checks were not run.

Verification commands (repository root, after building):
  python3 color-modes/lv-boost/test_lv_boost.py -v
  python3 color-modes/lv-boost/verify_card.py /tmp/lv-boost-fs3
  cd fp_usb_shell
  python3 -m unittest test_boot_chain test_loader_hook test_splash

SHA256SUMS identifies the exact packaged files. These hashes are for
traceability, not a runtime AutoRun/BIN pairing requirement.
